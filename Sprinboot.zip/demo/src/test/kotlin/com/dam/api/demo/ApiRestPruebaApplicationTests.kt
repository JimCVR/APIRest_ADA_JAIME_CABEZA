package com.dam.api.demo

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ApiRestPruebaApplicationTests {

	@Test
	fun contextLoads() {
	}

}
